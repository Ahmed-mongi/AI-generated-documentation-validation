# batch_eval.py
import json
from validator import DocumentationValidator

validator = DocumentationValidator(model_path="models/CodeBERT", threshold=0.75)

with open("data/csn_synthetic.json") as f:
    samples = json.load(f)["samples"]

results = []

for s in samples:
    # LLM-generated docstring
    r = validator.validate_single(s["code"], s["ai_generated_docstring"])
    # Ground truth docstring
    gt_r = validator.validate_single(s["code"], s["ground_truth_docstring"])

    results.append({
        "code": s["code"],
        "generated_doc": s["ai_generated_docstring"],
        "ground_truth_doc": s["ground_truth_docstring"],
        "label": r.label,
        "similarity": r.similarity_score,
        "hallucination": r.error_type,
        "gt_similarity": gt_r.similarity_score
    })

with open("results/batch_eval.json", "w") as f:
    json.dump(results, f, indent=2)

print(f"Saved batch evaluation results for {len(results)} samples.")
