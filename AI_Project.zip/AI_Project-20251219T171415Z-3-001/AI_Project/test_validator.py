# test_validator.py
from validator import DocumentationValidator

validator = DocumentationValidator(model_name="models/CodeBERT", threshold=0.75)

samples = [
    {"code": "def add(a, b): return a + b", "ai_generated_docstring": "Adds two numbers together."},
    {"code": "def multiply(x, y): return x * y", "ai_generated_docstring": "Divides two numbers."},
]

for s in samples:
    r = validator.validate_single(s["code"], s["ai_generated_docstring"])
    print(f"Code: {s['code']}\nDoc: {s['ai_generated_docstring']}")
    print(f"Label: {'CONSISTENT' if r.is_consistent else 'PARTIAL'}, Similarity: {r.similarity_score:.3f}, Hallucination: {r.details['hallucination']}\n")
