# validator.py
import os
import torch
from transformers import AutoTokenizer, AutoModel
from dataclasses import dataclass
from typing import Dict, Any
from csn_loader import load_csn

@dataclass
class ValidationResult:
    code_similarity: float
    doc_similarity: float
    hallucination: str

class DocumentationValidator:
    def __init__(self, model_name="models/CodeBERT", threshold=0.75):
        self.threshold = threshold
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model_dir = model_name
        
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_dir, local_files_only=True)
        self.model = AutoModel.from_pretrained(self.model_dir, local_files_only=True).to(self.device)
        self.csn_data = load_csn()  # load CSN reference
        
    def embed_text(self, text: str):
        inputs = self.tokenizer(text, return_tensors="pt", truncation=True, max_length=512).to(self.device)
        with torch.no_grad():
            output = self.model(**inputs)
            embeddings = output.last_hidden_state.mean(dim=1)
        return embeddings

    def cosine_similarity(self, emb1, emb2):
        return torch.nn.functional.cosine_similarity(emb1, emb2).item()

    def validate(self, task_key: str, ai_code: str, ai_doc: str) -> ValidationResult:
        # Get ground-truth
        ref = self.csn_data.get(task_key)
        if not ref:
            raise ValueError(f"No CSN reference found for task {task_key}")
        
        code_sim = self.cosine_similarity(self.embed_text(ai_code), self.embed_text(ref["code"]))
        doc_sim = self.cosine_similarity(self.embed_text(ai_doc), self.embed_text(ref["docstring"]))
        
        hallucination = "none"
        if code_sim < self.threshold or doc_sim < self.threshold:
            hallucination = "fabrication"
        
        return ValidationResult(
            code_similarity=code_sim,
            doc_similarity=doc_sim,
            hallucination=hallucination
        )
