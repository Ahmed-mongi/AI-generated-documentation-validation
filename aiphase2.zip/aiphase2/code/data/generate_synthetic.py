#!/usr/bin/env python3
"""
Generates synthetic dataset JSONL for experiments.
"""
import json
from pathlib import Path
out = Path("data/synthetic_dataset.jsonl")
out.parent.mkdir(parents=True, exist_ok=True)

examples = []
for i in range(200):
    code = f"def foo_{i}(a, b):\\n    # example {i}\\n    return a + b"
    target = "adds two numbers"
    examples.append({"id": i, "input": code, "target": target, "meta": {"difficulty": "easy"}})

with open(out, "w") as f:
    for e in examples:
        f.write(json.dumps(e) + "\\n")
print("Wrote", out)
