# generator_codeparrot.py
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

class CodeGenerator:
    def __init__(self, model_name="codeparrot/codeparrot-small"):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        print(f"Using device: {self.device}")

        # Load tokenizer and model
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForCausalLM.from_pretrained(model_name).to(self.device)

        self.model.eval()
        print(f"{model_name} loaded successfully.")

    def generate_code(self, prompt: str, max_tokens: int = 150):
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)

        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=max_tokens,
                do_sample=True,
                temperature=0.7,
                top_p=0.95,
                pad_token_id=self.tokenizer.eos_token_id
            )

        return self.tokenizer.decode(outputs[0], skip_special_tokens=True)
