#!/usr/bin/env python3
"""
sample_prompt_logger.py
- Configurable model, prompt template use
- Mock model responses by default (so you can run offline)
- Writes structured logs to logs/run_log.json
"""
import os, json, argparse, uuid
from datetime import datetime, UTC

LOGFILE = "logs/run_log.json"

def ensure_logs():
    os.makedirs("logs", exist_ok=True)
    if not os.path.exists(LOGFILE):
        with open(LOGFILE, "w") as f:
            json.dump([], f, indent=2)

def log_entry(prompt, response, model, params):
    entry = {
        "id": str(uuid.uuid4()),
        "timestamp": datetime.now(UTC).isoformat(),
        "model": model,
        "params": params,
        "prompt": prompt,
        "response": response
    }
    with open(LOGFILE, "r") as f:
        data = json.load(f)
    data.append(entry)
    with open(LOGFILE, "w") as f:
        json.dump(data, f, indent=2)

def call_model_mock(prompt, model, params):
    # Replace this function with a real API invocation when ready
    return f"MOCK_REPLY for model={model}: summary of input length {len(prompt)}"

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--prompt-file", help="File containing prompt or code", default=None)
    parser.add_argument("--prompt", help="Inline prompt", default=None)
    parser.add_argument("--model", default="gpt-4o-mini")
    parser.add_argument("--temp", type=float, default=0.2)
    args = parser.parse_args([]) # Pass an empty list to ignore Jupyter's arguments

    ensure_logs()

    if args.prompt_file:
        with open(args.prompt_file) as f:
            prompt = f.read()
    elif args.prompt:
        prompt = args.prompt
    else:
        prompt = "def add(a,b): return a+b"

    params = {"temperature": args.temp}
    # Call model (mock here)
    response = call_model_mock(prompt, args.model, params)
    log_entry(prompt, response, args.model, params)
    print("Logged entry. Example response:")
    print(response)

if __name__ == "__main__":
    main()
