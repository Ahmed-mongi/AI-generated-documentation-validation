# Samples of correct outputs
Input: def add(a,b): return a+b
Output: Adds two numbers.

# Samples of incorrect outputs
Input: def load_config(path): ...
Output: "Uses config from remote database" (fabricated)
