import streamlit as st
import requests

st.title("AI Code Documentation Validator & Generator")

tab = st.tabs(["Validate Documentation", "Generate Code"])

with tab[0]:
    st.header("Validate Documentation")
    code_input = st.text_area("Code")
    doc_input = st.text_area("AI-generated Docstring")
    if st.button("Validate"):
        response = requests.post("http://127.0.0.1:8000/validate", json={
            "code": code_input,
            "ai_doc": doc_input,
            "prompt": ""
        })
        st.json(response.json())

with tab[1]:
    st.header("Generate Code")
    prompt_input = st.text_area("Prompt")
    if st.button("Generate"):
        response = requests.post("http://127.0.0.1:8000/generate", json={
            "code": "",
            "ai_doc": "",
            "prompt": prompt_input
        })
        st.code(response.json()["generated_code"])
