# test_generator.py
from generator import CodeGenerator

generator = CodeGenerator()

prompts = [
    "Write a Python function to compute the Fibonacci sequence with a docstring.",
    "Create a Python function that checks if a number is prime.",
    "Write a Python class BankAccount with deposit and withdraw methods."
]

for i, prompt in enumerate(prompts, 1):
    print(f"\nPrompt {i}: {prompt}")
    print("-" * 60)
    code = generator.generate_code(prompt)
    print(code)
