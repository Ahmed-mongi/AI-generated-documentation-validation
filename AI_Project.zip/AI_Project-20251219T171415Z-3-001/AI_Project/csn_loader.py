# csn_loader.py
import json
import os
import kagglehub

CSN_PATH = "data/codesearchnet"

def download_csn():
    if not os.path.exists(CSN_PATH):
        print("Downloading CodeSearchNet dataset via KaggleHub...")
        kagglehub.dataset_download("omduggineni/codesearchnet")
        print("Downloaded CSN to", CSN_PATH)
    else:
        print("CSN dataset already exists.")

def load_csn(language="python"):
    """
    Returns a dictionary: task_key -> {code, docstring}
    For simplicity, task_key can be function name or descriptive key.
    """
    download_csn()
    csn_file = os.path.join(CSN_PATH, f"{language}_functions.json")  # adjust path/filename
    if not os.path.exists(csn_file):
        raise FileNotFoundError(f"{csn_file} not found in CSN dataset.")
    
    csn_data = {}
    with open(csn_file, "r") as f:
        for line in f:
            item = json.loads(line)
            # CSN provides 'function_name', 'code', 'docstring'
            key = item.get("function_name") or item.get("key") or f"func_{len(csn_data)}"
            csn_data[key] = {
                "code": item.get("code", ""),
                "docstring": item.get("docstring", "")
            }
    return csn_data
