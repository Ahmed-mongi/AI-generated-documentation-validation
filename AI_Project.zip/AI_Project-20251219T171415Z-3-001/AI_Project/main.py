from fastapi import FastAPI
from pydantic import BaseModel
from validator import DocumentationValidator
from generator import CodeGenerator  # updated import

app = FastAPI()
validator = DocumentationValidator()
generator = CodeGenerator(model_name="models/PolyCoder-125M")  # offline PolyCoder

class CodeRequest(BaseModel):
    code: str
    ai_doc: str
    prompt: str

@app.post("/validate")
def validate_code(req: CodeRequest):
    res = validator.validate_single(req.code, req.ai_doc)
    return {
        "code": req.code,
        "doc": req.ai_doc,
        "similarity": res.similarity_score,
        "label": "CONSISTENT" if res.is_consistent else "PARTIAL",
        "hallucination": res.details["hallucination"]
    }

@app.post("/generate")
def generate_code(req: CodeRequest):
    code = generator.generate_code(req.prompt)
    return {"generated_code": code}
